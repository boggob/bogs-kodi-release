from .alphabet_detector import *
__version__ = '0.0.5'
VERSION = tuple(map(int, __version__.split('.')))
